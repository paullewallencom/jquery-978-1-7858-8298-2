$(() => {
  $('div.chapter a')
    .attr({ rel: 'external' });
});
