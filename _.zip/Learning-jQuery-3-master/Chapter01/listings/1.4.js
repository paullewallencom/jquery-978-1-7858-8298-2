$(() => {
  console.log('hello');
  console.log(52);
  console.log($('div.poem-stanza'));
});
