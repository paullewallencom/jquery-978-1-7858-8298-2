$(() => {
  $('#selected-plays > li')
    .addClass('horizontal');
});
