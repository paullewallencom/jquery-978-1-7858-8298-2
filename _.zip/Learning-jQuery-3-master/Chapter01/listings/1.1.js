function addHighlightClass() {
  $('div.poem-stanza').addClass('highlight');
}

$(addHighlightClass);
