$(() => {
  $('div.poem-stanza').addClass('highlight');
});
