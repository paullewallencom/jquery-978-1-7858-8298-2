$(() => {
  $('#switcher-large')
    .on('click', () => {
      $('body').addClass('large');
    });
});
