$(() => {
  $('#switcher-large')
    .click(() => {

    });
});
