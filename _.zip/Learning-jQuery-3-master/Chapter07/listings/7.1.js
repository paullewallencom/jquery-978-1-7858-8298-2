$(() => {
  $('#books').cycle();
});
